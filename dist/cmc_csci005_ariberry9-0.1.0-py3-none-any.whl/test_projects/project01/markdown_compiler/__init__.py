'''
This file contains functions that work on entire documents at a time
(and not line-by-line).
'''

import re

from markdown_compiler.util.line_functions import *


def compile_lines(text):
    r'''
    (doctests unchanged)
    '''
    lines = text.split('\n')
    new_lines = []
    in_paragraph = False
    in_codeblock = False

    for raw in lines:
        line = raw

        if line.strip() == "```":
            if in_paragraph:
                new_lines.append("</p>")
                in_paragraph = False

            if not in_codeblock:
                new_lines.append("<pre>")
                in_codeblock = True
            else:
                new_lines.append("</pre>")
                in_codeblock = False
            continue

        if in_codeblock:
            new_lines.append(line)
            continue

        line = line.strip()

        if line == '':
            if in_paragraph:
                new_lines.append("</p>")
                in_paragraph = False
            else:
                new_lines.append("")
            continue

        if line[0] != '#' and not in_paragraph:
            in_paragraph = True
            line = "<p>\n" + line

        line = compile_headers(line)
        line = compile_strikethrough(line)
        line = compile_bold_stars(line)
        line = compile_bold_underscore(line)
        line = compile_italic_star(line)
        line = compile_italic_underscore(line)
        line = compile_code_inline(line)
        line = compile_images(line)
        line = compile_links(line)

        new_lines.append(line)

    if in_paragraph:
        new_lines.append("</p>")
        in_paragraph = False

    while new_lines and new_lines[-1] == "":
        new_lines.pop()

    return '\n'.join(new_lines)


def markdown_to_html(markdown, add_css=False):
    '''
    Convert the input markdown into valid HTML,
    optionally adding CSS formatting.

    NOTE:
    This function is separated out from the `compile_lines` function so that the doctests are much simpler.
    In particular, by splitting these functions in two,
    there's no need to add all of the HTML boilerplate code to the doctests in `compile_lines`.

    NOTE:
    The code for this function is simple enough that we don't even have a "real" doctest.
    The only purpose of this doctest is to run the function and ensure that there are no errors.
    The `assert` function prints no output whenever the input is "truthy".

    >>> assert(markdown_to_html('this *is* a _test_', False))
    >>> assert(markdown_to_html('this *is* a _test_', True))
    '''

    html = '''
<html>
<head>
    <style>
    ins { text-decoration: line-through; }
    </style>
    '''
    if add_css:
        html += '''
<link rel="stylesheet" href="https://izbicki.me/css/code.css" />
<link rel="stylesheet" href="https://izbicki.me/css/default.css" />
        '''
    html += '''
</head>
<body>
    ''' + compile_lines(markdown) + '''
</body>
</html>
    '''
    return html


def minify(html):
    r'''
    Remove redundant whitespace (spaces and newlines) from the input HTML,
    and convert all whitespace characters into spaces.

    NOTE:
    When we transfer HTML files over the internet,
    we'd like them to be as small as possible in order to save bandwidth and make the webpage load faster.
    Minifying html documents is an important step for webservers.
    It may not seem like much, but at the scale of Google/Facebook,
    it can reduce costs by millions of dollars annually.

    >>> minify('       ')
    ''
    >>> minify('   a    ')
    'a'
    >>> minify('   a    b        c    ')
    'a b c'
    >>> minify('a b c')
    'a b c'
    >>> minify('a\nb\nc')
    'a b c'
    >>> minify('a \nb\n c')
    'a b c'
    >>> minify('a\n\n\n\n\n\n\n\n\n\n\n\n\n\nb\n\n\n\n\n\n\n\n\n\n')
    'a b'
    '''
    return re.sub(r'\s+', ' ', html).strip()


def convert_file(input_file, add_css=False):
    '''
    Convert the input markdown file into an HTML file.
    If the input filename is `README.md`,
    then the output filename will be `README.html`.

    NOTE:
    It is difficult to write meaningful doctests for functions that deal with files.
    This is because we would have to create a bunch of different files to do so.
    Therefore, there are no tests for this function.
    But we can still be confident that this function will work because of the extensive tests on the "helper functions" that this function depends on.
    '''

    # validate that the input file is a markdown file
    if input_file[-3:] != '.md':
        raise ValueError('input_file does not end in .md')

    # load the input file
    with open(input_file, 'r') as f:
        markdown = f.read()

    # generate the HTML from the Markdown
    html = markdown_to_html(markdown, add_css)
    html = minify(html)

    # write the output file
    with open(input_file[:-2] + 'html', 'w') as f:
        f.write(html)
